
Welcome,

A casual Sans typeset. WOFF2, WOFF, TTF 

Implemented w/ mobile App project: bowHip.org">bowHip.org and visorglasses.com

Includes 2 additional outliner fonts.
You'll like this font if you use any of these: Sego | Noto | Source Sans Pro | Open Sans

Join project 
<a href="mailto: support@bowhip.org
Github.com/qp5/FONT/raw/main/FONT.zip

TODO LIST
 - add to Google fonts
 - improve italics
 - Guide to font forge
 - help with open source license


feedback: support@bowhip.org
    
____________________________________________________________
Other projects: Github.com/qp5/
